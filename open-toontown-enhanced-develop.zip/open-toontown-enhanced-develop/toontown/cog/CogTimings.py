dict = {}
fromSky = 6.5
toSky = 6.5
victoryDance = 9.08
fromCogBuilding = 2.0
toCogBuilding = 2.5
toToonBuilding = 2.5
