from direct.distributed.DistributedObjectGlobal import DistributedObjectGlobal
from direct.directnotify.DirectNotifyGlobal import directNotify

class SnapshotRenderer(DistributedObjectGlobal):
    pass
