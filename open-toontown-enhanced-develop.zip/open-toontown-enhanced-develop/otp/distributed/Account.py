from direct.distributed import DistributedObject

class Account(DistributedObject.DistributedObject):

    def __init__(self, cr):
        pass
