

class PotentialShard:

    def __init__(self, id):
        self.id = id
        self.name = None
        self.population = 0
        self.welcomeValleyPopulation = 0
        self.active = 1
        self.available = 1
        return
