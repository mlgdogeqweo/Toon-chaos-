from direct.distributed import DistributedObject


class AstronAccount(DistributedObject.DistributedObject):

    def __init__(self, cr):
        pass
